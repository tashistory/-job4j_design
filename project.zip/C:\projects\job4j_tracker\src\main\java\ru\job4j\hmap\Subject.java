package ru.job4j.hmap;

public record Subject(String name, int score) {
}
