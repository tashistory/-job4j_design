package ru.job4j.collection;

import static org.junit.jupiter.api.Assertions.*;

class ConvertMatrix2ListTest {

}