package ru.job4j.inheritance;

public class Profession {
    private boolean degree;

    public Profession(boolean degree) {
        this.degree = degree;
    }
}
