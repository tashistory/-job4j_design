package ru.job4j.oop;

public class Wolf {
    void tryEat(Ball ball) {
        ball.tryRun(false);
    }
}
