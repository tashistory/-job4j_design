package ru.job4j.stream;

public enum Value {
    V_6, V_7, V_8
}
