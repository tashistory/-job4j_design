package ru.job4j.oop;

public class Fox {
    void tryEat(Ball ball) {
        ball.tryRun(true);
    }
}
