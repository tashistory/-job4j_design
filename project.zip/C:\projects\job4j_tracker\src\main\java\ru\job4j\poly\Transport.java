package ru.job4j.poly;

public interface Transport {
    public void drive();

    public void numberOfPass(int pass);

    public double refuel(double fuel);
}
