package ru.job4j.oop;

public class Hare {
    void tryEat(Ball ball) {
        ball.tryRun(false);
    }
}
